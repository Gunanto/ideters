# ideters starter kit v1

Starter kit ini disusun untuk proyek **ideters** dengan pendekatan **docker-compose first**.

## Isi starter

- Next.js App Router + TypeScript + TailwindCSS
- utilitas Markdown + LaTeX + KaTeX pre-render
- layer service awal untuk course, module, activity, dan quiz
- PostgreSQL lokal untuk bootstrap development dan testing query
- MinIO + auto bucket init
- Mailpit untuk simulasi email development
- schema SQL awal yang kompatibel untuk dipakai di Supabase SQL Editor atau Postgres lokal

## Catatan penting

Starter ini **belum membundel seluruh stack self-hosted Supabase resmi**. App sudah dipersiapkan untuk terhubung ke **Supabase managed** atau **Supabase self-hosted** lewat environment variables. Pendekatan ini menjaga starter tetap ringan dan mudah dijalankan, sambil tetap cocok dengan arsitektur docker-compose-first. Supabase mendokumentasikan Docker sebagai cara termudah untuk self-host, self-hosting juga tersedia sebagai Docker Compose deployment, dan self-hosted Storage dapat dikonfigurasi memakai backend S3-compatible seperti MinIO. citeturn0search0turn0search1turn0search4

## Quick start

1. Salin env:

```bash
cp .env.example .env
```

2. Jalankan starter:

```bash
docker compose up -d --build
```

3. Buka aplikasi:

- Web: `http://localhost:3000`
- MinIO Console: `http://localhost:9001`
- Mailpit UI: `http://localhost:8025`
- Postgres: `localhost:5432`

## Struktur penting

```txt
apps/web              aplikasi Next.js
infra/db/init         bootstrap schema SQL lokal
infra/minio           catatan setup MinIO
```

## Menyambungkan Supabase

Set env berikut di `.env`:

```env
NEXT_PUBLIC_SUPABASE_URL=
NEXT_PUBLIC_SUPABASE_ANON_KEY=
SUPABASE_SERVICE_ROLE_KEY=
```

App Router di Next.js memang cocok untuk aplikasi full-stack modern dan mendukung Server Components, Suspense, dan Server Functions. citeturn0search2turn0search9

## Pengembangan berikutnya

- sambungkan auth login/register ke Supabase Auth
- ganti layer service mock menjadi query nyata ke Supabase
- tambahkan upload file ke Supabase Storage atau adapter storage MinIO
- pecah domain menjadi packages terpisah bila tim mulai membesar
