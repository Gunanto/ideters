import { Shell } from '@/components/layout/shell';

export default function LoginPage() {
  return (
    <Shell>
      <div className="mx-auto max-w-lg rounded-3xl border border-slate-200 bg-white p-8 shadow-sm">
        <h1 className="text-2xl font-semibold">Login</h1>
        <p className="mt-2 text-sm text-slate-600">
          Halaman ini masih placeholder. Sambungkan ke Supabase Auth pada iterasi berikutnya.
        </p>
        <form className="mt-8 space-y-4">
          <div>
            <label className="mb-2 block text-sm font-medium">Email</label>
            <input className="w-full rounded-2xl border border-slate-300 px-4 py-3 outline-none" type="email" placeholder="you@example.com" />
          </div>
          <div>
            <label className="mb-2 block text-sm font-medium">Password</label>
            <input className="w-full rounded-2xl border border-slate-300 px-4 py-3 outline-none" type="password" placeholder="••••••••" />
          </div>
          <button type="button" className="w-full rounded-2xl bg-slate-950 px-5 py-3 text-sm font-medium text-white">
            Masuk
          </button>
        </form>
      </div>
    </Shell>
  );
}
