import { Shell } from '@/components/layout/shell';
import { MarkdownRenderer } from '@/lib/content/render-markdown';
import { listCourses } from '@/lib/services/course-service';

export default async function DashboardPage() {
  const courses = await listCourses();
  const firstActivity = courses[0]?.modules[0]?.activities[0];

  return (
    <Shell>
      <div className="grid gap-8 lg:grid-cols-[0.9fr_1.1fr]">
        <section className="rounded-3xl border border-slate-200 bg-white p-8 shadow-sm">
          <h1 className="text-2xl font-semibold">Dashboard</h1>
          <p className="mt-2 text-sm text-slate-600">Halaman ini menunjukkan arah awal course viewer dan preview konten ter-render.</p>
          <div className="mt-6 space-y-4">
            {courses.map((course) => (
              <div key={course.id} className="rounded-2xl border border-slate-200 p-4">
                <h2 className="font-medium">{course.title}</h2>
                <p className="mt-1 text-sm text-slate-600">{course.description}</p>
              </div>
            ))}
          </div>
        </section>

        <section className="rounded-3xl border border-slate-200 bg-white p-8 shadow-sm">
          <h2 className="text-xl font-semibold">Preview Markdown + LaTeX</h2>
          <div className="mt-6">
            <MarkdownRenderer content={firstActivity?.content ?? '# Belum ada konten'} />
          </div>
        </section>
      </div>
    </Shell>
  );
}
