import './globals.css';
import type { Metadata } from 'next';

export const metadata: Metadata = {
  title: 'ideters starter kit',
  description: 'Starter kit v1 untuk LMS ideters.'
};

export default function RootLayout({ children }: Readonly<{ children: React.ReactNode }>) {
  return (
    <html lang="id">
      <body>{children}</body>
    </html>
  );
}
