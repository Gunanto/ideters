import Link from 'next/link';

import { Shell } from '@/components/layout/shell';
import { Badge } from '@/components/ui/badge';
import { listCourses, listLearningSyntaxes } from '@/lib/services/course-service';

export default async function HomePage() {
  const [courses, syntaxes] = await Promise.all([listCourses(), listLearningSyntaxes()]);

  return (
    <Shell>
      <section className="grid gap-8 lg:grid-cols-[1.4fr_1fr]">
        <div className="rounded-3xl border border-slate-200 bg-white p-8 shadow-sm">
          <div className="mb-4 flex gap-3">
            <Badge>Next.js App Router</Badge>
            <Badge>Supabase-ready</Badge>
            <Badge>MinIO-ready</Badge>
          </div>
          <h1 className="max-w-3xl text-4xl font-semibold tracking-tight text-slate-950">
            Starter kit v1 untuk membangun LMS ideters yang modular dan docker-compose first.
          </h1>
          <p className="mt-4 max-w-2xl text-base leading-7 text-slate-600">
            Fondasi ini menyiapkan course, module, activity, learning syntax, quiz, dan rendering Markdown + LaTeX.
          </p>
          <div className="mt-8 flex gap-4">
            <Link href="/dashboard" className="rounded-2xl bg-slate-950 px-5 py-3 text-sm font-medium text-white">
              Buka dashboard
            </Link>
            <Link href="/login" className="rounded-2xl border border-slate-300 bg-white px-5 py-3 text-sm font-medium">
              Halaman login
            </Link>
          </div>
        </div>

        <div className="rounded-3xl border border-slate-200 bg-white p-8 shadow-sm">
          <h2 className="text-lg font-semibold">Learning syntax awal</h2>
          <ul className="mt-5 space-y-3 text-sm text-slate-700">
            {syntaxes.map((syntax) => (
              <li key={syntax.id} className="rounded-2xl border border-slate-200 p-4">
                {syntax.name}
              </li>
            ))}
          </ul>
        </div>
      </section>

      <section className="mt-10 rounded-3xl border border-slate-200 bg-white p-8 shadow-sm">
        <h2 className="text-xl font-semibold">Contoh course</h2>
        <p className="mt-2 text-sm text-slate-600">Data saat ini masih mock, siap diganti ke Supabase query.</p>
        <div className="mt-6 grid gap-4 md:grid-cols-2">
          {courses.map((course) => (
            <article key={course.id} className="rounded-2xl border border-slate-200 p-5">
              <h3 className="text-lg font-semibold">{course.title}</h3>
              <p className="mt-2 text-sm text-slate-600">{course.description}</p>
              <p className="mt-4 text-sm text-slate-500">{course.modules.length} modul</p>
            </article>
          ))}
        </div>
      </section>
    </Shell>
  );
}
