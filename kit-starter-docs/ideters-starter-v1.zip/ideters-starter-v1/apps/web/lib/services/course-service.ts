import { mockCourses, mockLearningSyntaxes } from './mock-data';

export async function listCourses() {
  return mockCourses;
}

export async function getCourseBySlug(slug: string) {
  return mockCourses.find((course) => course.slug === slug) ?? null;
}

export async function listLearningSyntaxes() {
  return mockLearningSyntaxes;
}
