export const mockCourses = [
  {
    id: 'course-aljabar-dasar',
    slug: 'aljabar-dasar',
    title: 'Aljabar Dasar',
    description: 'Course contoh untuk starter kit ideters.',
    modules: [
      {
        id: 'module-1',
        title: 'Pengenalan Persamaan',
        activities: [
          {
            id: 'activity-1',
            type: 'syntax_activity',
            title: 'Pemantik → Materi → Latihan → Refleksi',
            content: `# Tujuan Belajar

Pahami bentuk umum persamaan linear.

## Rumus

Inline: $ax + b = 0$

Block:

$$x = -\frac{b}{a}$$`
          },
          {
            id: 'activity-2',
            type: 'quiz',
            title: 'Quiz singkat persamaan linear',
            content: 'Quiz placeholder untuk v1 starter.'
          }
        ]
      }
    ]
  }
];

export const mockLearningSyntaxes = [
  { id: 'syntax-1', name: 'Pemantik → Materi → Latihan → Refleksi' },
  { id: 'syntax-2', name: 'Observasi → Hipotesis → Eksperimen → Diskusi' },
  { id: 'syntax-3', name: 'Problem Based Learning Sederhana' }
];
