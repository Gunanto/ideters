# Notes

## Kenapa starter ini tidak memaksa full self-hosted Supabase?

Agar repo awal tetap ringan, cepat di-boot, dan fokus pada domain LMS. Konfigurasi penuh self-hosted Supabase biasanya lebih besar dan lebih cocok dipisah menjadi repo infra atau compose override khusus deployment.

## Rekomendasi mode kerja

- local dev: docker compose starter ini + Supabase managed/self-hosted terpisah
- staging/prod: compose override untuk stack penuh atau deployment terpisah
