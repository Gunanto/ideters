# MinIO

Bucket yang dibuat otomatis:
- course-assets
- course-thumbnails
- exports

MinIO menyediakan object storage yang kompatibel dengan S3. citeturn0search3
