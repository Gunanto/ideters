# ideters starter v2

Starter kit **docker-compose first** untuk proyek LMS **ideters**.

## Yang ada di starter ini

- **Next.js App Router + TypeScript + TailwindCSS**
- **Docker Compose** untuk:
  - `web` (Next.js)
  - `postgres`
  - `minio`
  - `mailpit`
  - `adminer`
- **Schema database awal** untuk course, module, activity, learning syntax, quiz, progress
- **Markdown + LaTeX + KaTeX pre-render**
- **Seed data awal**
- **Healthcheck**
- **Makefile** untuk workflow harian

## Catatan penting

Starter ini sengaja dibuat **production-leaning** tetapi tetap ringan untuk development.
Ia **belum membundel seluruh stack resmi self-hosted Supabase** karena stack itu cukup berat dan kompleks.
Sebagai gantinya, starter ini menyiapkan:

- skema database yang kompatibel dengan arah arsitektur Supabase
- env yang mudah diganti ke Supabase managed / self-hosted
- object storage dengan **MinIO**
- struktur kode yang siap ditingkatkan ke auth/storage Supabase

## Menjalankan

```bash
cp .env.example .env
docker compose up --build
```

Akses:
- app: http://localhost:3000
- mailpit: http://localhost:8025
- adminer: http://localhost:8080
- minio console: http://localhost:9001

## Login database dari Adminer

- System: PostgreSQL
- Server: postgres
- Username: ideters
- Password: ideters
- Database: ideters

## Perintah umum

```bash
make up
make down
make logs
make shell-web
make lint
make typecheck
```

## Roadmap v3 yang paling masuk akal

- Supabase Auth nyata
- upload asset ke storage adapter
- course/module/activity CRUD penuh
- quiz builder
- RLS migration khusus Supabase
