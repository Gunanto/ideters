import { sampleCourse } from "@/lib/domain/sample-data";
import { MarkdownContent } from "@/components/content/markdown-content";

export default function DashboardPage() {
  return (
    <main className="container-page py-10">
      <div className="grid gap-6 lg:grid-cols-[280px_1fr]">
        <aside className="card p-5">
          <h2 className="mb-4 text-lg font-semibold">Course Outline</h2>
          <div className="space-y-4">
            {sampleCourse.modules.map((module) => (
              <div key={module.id} className="rounded-xl border border-slate-200 p-4">
                <h3 className="font-medium">{module.title}</h3>
                <ul className="mt-3 space-y-2 text-sm text-slate-600">
                  {module.activities.map((activity) => (
                    <li key={activity.id}>
                      {activity.title} <span className="text-slate-400">({activity.type})</span>
                    </li>
                  ))}
                </ul>
              </div>
            ))}
          </div>
        </aside>

        <section className="space-y-6">
          <div className="card p-6">
            <h1 className="text-2xl font-bold">{sampleCourse.title}</h1>
            <p className="mt-2 text-slate-600">{sampleCourse.description}</p>
          </div>

          <div className="card p-6">
            <h2 className="text-xl font-semibold">{sampleCourse.modules[0].activities[0].title}</h2>
            <div className="mt-6">
              <MarkdownContent markdown={sampleCourse.modules[0].activities[0].content_markdown} />
            </div>
          </div>

          <div className="card p-6">
            <h2 className="text-xl font-semibold">Template learning syntax</h2>
            <div className="mt-4 grid gap-4 md:grid-cols-2">
              {sampleCourse.learningSyntaxes.map((syntax) => (
                <div key={syntax.id} className="rounded-xl border border-slate-200 p-4">
                  <h3 className="font-medium">{syntax.name}</h3>
                  <p className="mt-2 text-sm text-slate-600">{syntax.description}</p>
                  <ul className="mt-3 list-disc space-y-1 pl-5 text-sm text-slate-700">
                    {syntax.steps.map((step) => (
                      <li key={step.key}>{step.label} — {step.type}</li>
                    ))}
                  </ul>
                </div>
              ))}
            </div>
          </div>
        </section>
      </div>
    </main>
  );
}
