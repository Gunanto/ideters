import Link from "next/link";
import { sampleCourse } from "@/lib/domain/sample-data";
import { MarkdownContent } from "@/components/content/markdown-content";

export default function HomePage() {
  return (
    <main className="container-page py-10">
      <section className="card grid gap-8 p-8 lg:grid-cols-2">
        <div className="space-y-5">
          <span className="inline-flex rounded-full bg-brand-50 px-3 py-1 text-sm font-medium text-brand-700">
            ideters starter v2
          </span>
          <h1 className="text-4xl font-bold tracking-tight text-slate-900">
            LMS modular berbasis course, syntax pembelajaran, dan quiz.
          </h1>
          <p className="text-lg text-slate-600">
            Starter docker-compose first untuk membangun produk serupa Canvas,
            tetapi lebih fokus pada template pedagogi dan konten Markdown + LaTeX.
          </p>
          <div className="flex gap-3">
            <Link className="rounded-xl bg-brand-500 px-4 py-2 font-medium text-white" href="/dashboard">
              Buka dashboard demo
            </Link>
            <a
              className="rounded-xl border border-slate-300 px-4 py-2 font-medium text-slate-700"
              href="http://localhost:9001"
            >
              MinIO Console
            </a>
          </div>
        </div>
        <div className="card p-6">
          <h2 className="mb-4 text-xl font-semibold">Contoh lesson dengan LaTeX</h2>
          <MarkdownContent markdown={sampleCourse.modules[0].activities[0].content_markdown} />
        </div>
      </section>
    </main>
  );
}
