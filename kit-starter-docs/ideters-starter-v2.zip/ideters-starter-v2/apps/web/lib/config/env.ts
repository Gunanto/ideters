import { z } from "zod";

const envSchema = z.object({
  NODE_ENV: z.enum(["development", "test", "production"]).default("development"),
  NEXT_PUBLIC_APP_NAME: z.string().default("ideters"),
  NEXT_PUBLIC_APP_URL: z.string().default("http://localhost:3000"),
  DATABASE_URL: z.string().default("postgresql://ideters:ideters@postgres:5432/ideters"),
  MINIO_ENDPOINT: z.string().default("http://minio:9000"),
  MINIO_BUCKET_COURSE_ASSETS: z.string().default("course-assets"),
  MINIO_BUCKET_THUMBNAILS: z.string().default("course-thumbnails"),
  MINIO_BUCKET_EXPORTS: z.string().default("exports")
});

export const env = envSchema.parse({
  NODE_ENV: process.env.NODE_ENV,
  NEXT_PUBLIC_APP_NAME: process.env.NEXT_PUBLIC_APP_NAME,
  NEXT_PUBLIC_APP_URL: process.env.NEXT_PUBLIC_APP_URL,
  DATABASE_URL: process.env.DATABASE_URL,
  MINIO_ENDPOINT: process.env.MINIO_ENDPOINT,
  MINIO_BUCKET_COURSE_ASSETS: process.env.MINIO_BUCKET_COURSE_ASSETS,
  MINIO_BUCKET_THUMBNAILS: process.env.MINIO_BUCKET_THUMBNAILS,
  MINIO_BUCKET_EXPORTS: process.env.MINIO_BUCKET_EXPORTS
});
