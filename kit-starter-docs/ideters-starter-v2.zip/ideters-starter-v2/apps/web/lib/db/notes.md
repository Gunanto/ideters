Database access layer dibiarkan tipis pada starter v2 ini.
Pada tahap berikutnya Anda bisa memilih:

- SQL murni + pg
- Drizzle ORM
- Kysely
- Supabase client

Karena target arsitektur Anda adalah Supabase, saya sarankan:
- query read sederhana lewat Supabase client
- domain logic tetap di service layer
- migration SQL tetap eksplisit di repo
