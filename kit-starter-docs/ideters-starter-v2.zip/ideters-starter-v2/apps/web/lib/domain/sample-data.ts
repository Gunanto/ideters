export const sampleCourse = {
  id: "course-demo-1",
  title: "Matematika Dasar dengan Syntax Pembelajaran",
  description: "Contoh starter course untuk menguji alur course, module, activity, dan quiz.",
  modules: [
    {
      id: "module-1",
      title: "Modul 1 — Aljabar Dasar",
      activities: [
        {
          id: "activity-1",
          type: "reading",
          title: "Pemantik dan konsep awal",
          content_markdown: `
## Tujuan
Mahasiswa memahami bentuk persamaan kuadrat.

Persamaan umum:

$$ax^2 + bx + c = 0$$

Rumus diskriminan:

$$D = b^2 - 4ac$$

Jika $D > 0$, maka ada dua akar real.
          `.trim()
        },
        {
          id: "activity-2",
          type: "quiz",
          title: "Quiz singkat"
        }
      ]
    }
  ],
  learningSyntaxes: [
    {
      id: "syntax-1",
      name: "Pemantik → Materi → Latihan → Refleksi",
      description: "Template paling dasar untuk pembelajaran terstruktur.",
      steps: [
        { key: "pemantik", label: "Pemantik", type: "markdown" },
        { key: "materi", label: "Materi", type: "markdown" },
        { key: "latihan", label: "Latihan", type: "quiz" },
        { key: "refleksi", label: "Refleksi", type: "markdown" }
      ]
    },
    {
      id: "syntax-2",
      name: "Observasi → Hipotesis → Eksperimen → Diskusi",
      description: "Template untuk scientific learning flow.",
      steps: [
        { key: "observasi", label: "Observasi", type: "markdown" },
        { key: "hipotesis", label: "Hipotesis", type: "markdown" },
        { key: "eksperimen", label: "Eksperimen", type: "assignment" },
        { key: "diskusi", label: "Diskusi", type: "discussion" }
      ]
    }
  ]
};
