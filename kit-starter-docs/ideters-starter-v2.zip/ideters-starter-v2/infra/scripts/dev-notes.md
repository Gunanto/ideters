# dev notes

## Kenapa starter ini belum full Supabase self-host?
Karena stack resmi self-hosted Supabase mencakup banyak service tambahan:
- kong
- auth
- rest
- realtime
- storage
- studio
- imgproxy
- meta

Itu sangat bagus untuk environment lanjut, tetapi untuk bootstrap produk
biasanya lebih efektif mulai dari:
- app
- postgres
- minio
- mailpit

Lalu tahap berikutnya tambahkan integrasi Supabase secara bertahap.

## Urutan upgrade yang disarankan
1. tambahkan auth Supabase
2. pindahkan query DB ke client/service layer
3. aktifkan storage adapter
4. tambahkan migration versioning
5. aktifkan background jobs untuk publish/re-render
